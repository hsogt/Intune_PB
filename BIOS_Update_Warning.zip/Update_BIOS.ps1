﻿#$Extract_Folder_Path = "C:\Windows\Temp\BIOS_Extract"
$Extract_Folder_Path = "C:\Windows\Temp\BIOS_Extract"
#$BIOS_Extract_Sources = "$Extract_Folder_Path\Extract_BIOS_Sources"
$BIOS_Extract_Sources = "$Extract_Folder_Path"
$WINUTP_Extract_Sources = "$BIOS_Extract_Sources"
$User_Continue_Process_File = "$Extract_Folder_Path\BIOS_Update_Continue.txt"
$WPF_Warning_Export_Folder = "C:\Windows\Temp\WPF_Warning"

If(!(test-path $Extract_Folder_Path)){new-item $Extract_Folder_Path -type Directory -force}

$Get_MTM = ((Get-CimInstance Win32_ComputerSystem).Model.SubString(0, 4)).Trim()
#$Log_File = "$env:SystemDrive\Windows\Debug\Remediation_BIOS_Update_$Get_MTM.log"
$Log_File = "C:\Windows\Logs\Software\Remediation_BIOS_Update_$Get_MTM.log"
If(!(test-path $Log_File)){new-item $Log_File -type file -force}

Function Write_Log
	{
		param(
		$Message_Type,	
		$Message
		)
		
		$MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
		Add-Content $Log_File  "$MyDate - $Message_Type : $Message"
		write-host  "$MyDate - $Message_Type : $Message"
	}
	
If(test-path $User_Continue_Process_File)
	{							
		Write_Log -Message_Type "INFO" -Message "The user validate the update process"	
		Write_Log -Message_Type "INFO" -Message "Suspending Bitlocker"
		
		$Check_Bitlocker_Status = Get-BitLockerVolume -MountPoint $env:SystemDrive | Select-Object -Property ProtectionStatus
		If ($Check_Bitlocker_Status.ProtectionStatus -eq "On") 
			{
				Try
					{
						Suspend-BitLocker -MountPoint $env:SystemDrive  -RebootCount 1 | out-null
						$Suspend_Bitlocker_Success = $True
						Write_Log -Message_Type "SUCCESS" -Message "Suspending Bitlocker"
						Write_Log -Message_Type "SUCCESS" -Message "Bitlocker will be anabled again at next reboot"
					}
				Catch
					{
						Write_Log -Message_Type "ERROR" -Message "Suspending Bitlocker"	
						EXIT
					}
			}	
		Else
			{
				$Suspend_Bitlocker_Success = $True
				Write_Log -Message_Type "SUCCESS" -Message "Bitlocker not enabled"
			}
						
		# If BitLocker has been successfully disabled, the BIOS is updated.
		If($Suspend_Bitlocker_Success -eq $True)
			{
				$BIOS_Extract_Sources = "C:\Windows\Temp\BIOS_Extract"
				
				#copy both WINUTO files and force overwrite
				$Files = @("WINUPTP.exe","WINUPTP64.exe")

				foreach ($File in $Files) {
					$SourceFile = Join-Path "C:\Windows\Temp\WPF_Warning" $File
					$DestFile   = Join-Path "C:\Windows\Temp\BIOS_Extract" $File

					if (Test-Path $SourceFile) {
						Copy-Item $SourceFile -Destination $DestFile -Force
						Write-Output "Copied: $SourceFile -> $DestFile"
					}
					else {
						Write-Output "File not found: $SourceFile"
					}
				}
				
				# BIOS Update installer silent switch
				$Silent_Switch = "-s"
				# Path of the BIOS installer
				#$WINUTP_Install_Path = "$BIOS_Extract_Sources\$WINUTP_Installer"
				$WINUTP_Install_Path = "$BIOS_Extract_Sources"
				$WINUTP_Installer = "$BIOS_Extract_Sources"
				# BIOS Update log name
				#$WINUTP_Log_File = "winuptp.log"
				$WINUTP_Log_File = "C:\Windows\Logs\Software\winuptp_$Get_MTM.log"
				# BIOS Update log path
				#$WINUTP_Log_Path = "$BIOS_Extract_Sources\$WINUTP_Log_File"
				$WINUTP_Log_Path = "$BIOS_Extract_Sources"
				
				Write_Log -Message_Type "INFO" -Message "Checking for BIOS installer files in path: $WINUTP_Install_Path ($BIOS_Extract_Sources) as reference under C:\Windows\Temp\BIOS_Extract.."
				<#
				If(!(test-path "$BIOS_Extract_Sources\WINUPTP64.exe"))
					{
						If(test-path "$BIOS_Extract_Sources\WINUPTP.exe")
							{
								$WINUTP_Installer = "WINUPTP.exe"
							}
					}
				Else
					{
						$WINUTP_Installer = "WINUPTP64.exe"
					}
				#>
				
				$Winutp64_Path = Join-Path $BIOS_Extract_Sources "WINUPTP64.exe"
				$Winutp32_Path = Join-Path $BIOS_Extract_Sources "WINUPTP.exe"
				$WFlash_Path   = Join-Path $BIOS_Extract_Sources "wFlashGUIX64.exe"
				$WFlash_Log_Path = Join-Path $BIOS_Extract_Sources "wflash_$Get_MTM.log" #"wflash.log"


				If (!(Test-Path $Winutp64_Path)) {
					Write_Log -Message_Type "WARNING" -Message "WINUPTP64.exe not found at: $Winutp64_Path"

					If (Test-Path $Winutp32_Path) {
						Write_Log -Message_Type "INFO" -Message "Found fallback BIOS installer: WINUPTP.exe at: $Winutp32_Path"
						$WINUTP_Installer = "WINUPTP.exe"
					}
					else {
						Write_Log -Message_Type "ERROR" -Message "No BIOS installer found in: $BIOS_Extract_Sources"
						Write_Log -Message_Type "ERROR" -Message "Checked paths: $Winutp64_Path and $Winutp32_Path"
						Break
					}
				}
				Else {
					Write_Log -Message_Type "INFO" -Message "Found BIOS installer: WINUPTP64.exe at: $Winutp64_Path"
					$WINUTP_Installer = "WINUPTP64.exe"
				}
				
				$Update_Success = $false
				$WINUTP_Installer = $null
				$Update_Process = $null
				
				<#
				If(test-path $WINUTP_Install_Path)
					{
						Write_Log -Message_Type "INFO" -Message "Updating BIOS update"
						Write_Log -Message_Type "INFO" -Message "Update path: $BIOS_Extract_Sources\$WINUTP_Installer"	

						$Update_Process = Start-Process -FilePath $WINUTP_Installer -WorkingDirectory $BIOS_Extract_Sources -ArgumentList $Silent_Switch -PassThru -Wait
						If(($Update_Process.ExitCode) -eq 1) 
							{
								Write_Log -Message_Type "INFO" -Message "Checking update state in log file"
								If(test-path $WINUTP_Log_Path)
									{			
										$Check_BIOSUpdate_Status_FromLog = ((Get-content $WINUTP_Log_Path | where-object { $_ -like "*BIOS Flash completed*"}) -ne "")		
										If($Check_BIOSUpdate_Status_FromLog -ne $null)
											{
												Write_Log -Message_Type "SUCCESS" -Message "Updating BIOS"
														Write_Log -Message_Type "INFO" -Message "Reboot pending"
												#start-process -WindowStyle hidden powershell.exe "$WPF_Warning_Export_Folder\Restart_Computer.ps1" -Wait
												# Direct system restart - 60 second delay
												shutdown.exe /r /f /t 60 /c "BIOS Update completed successfully. Your system will restart in 60 seconds."
												Write_Log -Message_Type "SUCCESS" -Message "System restart initiated (60 second delay)"
												Remove-item $BIOS_Update_Folder -Force -Recurse
												
												#copy-item $Log_File "C:\Windows\Debug\BIOS_Update_Completes.log"
												copy-item $Log_File "C:\Windows\Logs\Software\BIOS_Update_Completes.log"
												clear-content $Log_File -force
												
												#$BIOS_Update_Success_File = "C:\Windows\Debug\BIOS_Update_Success_File.txt"
												$BIOS_Update_Success_File = "C:\Windows\Logs\Software\BIOS_Update_Success_File.txt"
												new-item $BIOS_Update_Success_File -type file -force
												
												Break
											}
										Else
											{
												Write_Log -Message_Type "ERROR" -Message "Updating BIOS"
												Break
											}
									}
								Else
									{
										Write_Log -Message_Type "SUCCESS" -Message "File not found: $WINUTP_Log_Path"
									}
							}	
						Else
							{
								Write_Log -Message_Type "ERROR" -Message "Updating BIOS"
								Break
							}
					}
				Else
					{
						Write_Log -Message_Type "INFO" -Message "BIOS installer not found: $WINUTP_Install_Path"
					}
			}
	}
	#>
	If (Test-Path $WINUTP_Install_Path)
{
    Write_Log -Message_Type "INFO" -Message "Updating BIOS"

    # --- Try WINUPTP.exe first ---
    If (Test-Path $Winutp32_Path) {
        Write_Log -Message_Type "INFO" -Message "Attempting WINUPTP.exe at: $Winutp32_Path"

        $Update_Process = Start-Process -FilePath $Winutp32_Path `
                                        -WorkingDirectory $BIOS_Extract_Sources `
                                        -ArgumentList $Silent_Switch `
                                        -PassThru -Wait

        Write_Log -Message_Type "INFO" -Message "WINUPTP.exe ExitCode: $($Update_Process.ExitCode)"

        If ($Update_Process.ExitCode -eq 1) {
            $WINUTP_Installer = "WINUPTP.exe"
            $Update_Success = $true
        }
        else {
            Write_Log -Message_Type "WARNING" -Message "WINUPTP.exe failed"
        }
    }
    else {
        Write_Log -Message_Type "WARNING" -Message "WINUPTP.exe not found at: $Winutp32_Path"
    }

    # --- Try WINUPTP64.exe ---
    If (-not $Update_Success -and (Test-Path $Winutp64_Path)) {
        Write_Log -Message_Type "INFO" -Message "Attempting WINUPTP64.exe at: $Winutp64_Path"

        $Update_Process = Start-Process -FilePath $Winutp64_Path `
                                        -WorkingDirectory $BIOS_Extract_Sources `
                                        -ArgumentList $Silent_Switch `
                                        -PassThru -Wait

        Write_Log -Message_Type "INFO" -Message "WINUPTP64.exe ExitCode: $($Update_Process.ExitCode)"

        If ($Update_Process.ExitCode -eq 1) {
            $WINUTP_Installer = "WINUPTP64.exe"
            $Update_Success = $true
        }
        else {
            Write_Log -Message_Type "WARNING" -Message "WINUPTP64.exe failed"
        }
    }
    elseif (-not $Update_Success) {
        Write_Log -Message_Type "WARNING" -Message "WINUPTP64.exe not found at: $Winutp64_Path"
    }

    # --- Fallback: wFlashGUIX64.exe ---
    If (-not $Update_Success -and (Test-Path $WFlash_Path)) {
        Write_Log -Message_Type "INFO" -Message "Attempting fallback wFlashGUIX64.exe at: $WFlash_Path"

        $Update_Process = Start-Process -FilePath $WFlash_Path `
                                        -WorkingDirectory $BIOS_Extract_Sources `
                                        -ArgumentList "/quiet /log:$WFlash_Log_Path" `
                                        -PassThru -Wait

        Write_Log -Message_Type "INFO" -Message "wFlashGUIX64.exe ExitCode: $($Update_Process.ExitCode)"

        If ($Update_Process.ExitCode -eq 0) {
            $WINUTP_Installer = "wFlashGUIX64.exe"
            $Update_Success = $true
        }
        else {
            Write_Log -Message_Type "ERROR" -Message "wFlashGUIX64.exe failed"
        }
    }
    elseif (-not $Update_Success) {
        Write_Log -Message_Type "ERROR" -Message "wFlashGUIX64.exe not found at: $WFlash_Path"
    }

    # --- Continue only if success ---
    If ($Update_Success) {

        Write_Log -Message_Type "INFO" -Message "Update succeeded using: $WINUTP_Installer"
        Write_Log -Message_Type "INFO" -Message "Checking update state in log file"

        If (Test-Path $WINUTP_Log_Path)
        {
            $Check_BIOSUpdate_Status_FromLog = ((Get-Content $WINUTP_Log_Path | Where-Object { $_ -like "*BIOS Flash completed*" }) -ne "")

            If ($Check_BIOSUpdate_Status_FromLog -ne $null)
            {
                Write_Log -Message_Type "SUCCESS" -Message "Updating BIOS"
                Write_Log -Message_Type "INFO" -Message "Reboot pending"

                shutdown.exe /r /f /t 60 /c "BIOS Update completed successfully. Your system will restart in 60 seconds."

                Write_Log -Message_Type "SUCCESS" -Message "System restart initiated (60 second delay)"

                Remove-Item $BIOS_Update_Folder -Force -Recurse

                Copy-Item $Log_File "C:\Windows\Logs\Software\BIOS_Update_Completes.log"
                Clear-Content $Log_File -Force

                $BIOS_Update_Success_File = "C:\Windows\Logs\Software\BIOS_Update_Success_File.txt"
                New-Item $BIOS_Update_Success_File -Type File -Force

                Break
            }
            Else
            {
                Write_Log -Message_Type "ERROR" -Message "BIOS update completed but success string not found in log"
                Break
            }
        }
        Else
        {
            Write_Log -Message_Type "WARNING" -Message "Log file not found: $WINUTP_Log_Path"
        }
    }
    Else
    {
        Write_Log -Message_Type "ERROR" -Message "All BIOS update methods failed"
        Break
    }
}
Else
{
    Write_Log -Message_Type "INFO" -Message "BIOS installer path not found: $WINUTP_Install_Path"
}
}